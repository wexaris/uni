<div class="min-h-screen flex flex-col items-center pt-6 sm:pt-0 bg-gray-100">
    <div class="w-full sm:max-w-2xl mt-6 px-6 py-4 bg-white shadow-md sm:rounded-lg">
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH E:\Code\_uni\web2\md2\resources\views/components/form.blade.php ENDPATH**/ ?>