<?php $attributes = $attributes->exceptProps(['list', 'id', 'selected', 'text', 'disabled' => false]); ?>
<?php foreach (array_filter((['list', 'id', 'selected', 'text', 'disabled' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<select multiple id="<?php echo e($id); ?>" <?php echo e($disabled ? 'disabled' : ''); ?> <?php echo $attributes->merge(['class' => '']); ?>>
    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <?php if(collect($selected)->contains($item->value)): ?>
        <option value='<?php echo e($item->value); ?>' selected><?php echo e($item->name); ?></option>
        <?php else: ?>
        <option value='<?php echo e($item->value); ?>'><?php echo e($item->name); ?></option>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

<script>
    $(document).ready(function() {
        $('#<?php echo e($id); ?>').multiselect({
                    nonSelectedText:"<?php echo e($text); ?>",
                });
    });
</script><?php /**PATH E:\Code\_uni\web2\md2\resources\views/components/multi-select.blade.php ENDPATH**/ ?>